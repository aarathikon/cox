## How to run

 OS Dependencies:
```
sudo apt install awscli unzip
```

### Run terraform
```
terraform init
terraform plan
terraform apply
```

## How it works

- React application is built using npm command.
- Build files are kept in s3contents folder
- All files are uploaded to S3.
- All the static files are served from AWS CloudFront.

URL: https://d1uztmxeg1d2su.cloudfront.net/

